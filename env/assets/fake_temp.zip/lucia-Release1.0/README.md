# Lucia 1.0

Lucia is a simple, lightweight, and fast programming language made in python.

___

## Currently working on:

- Adding try-catch statement
- Fixing bugs
- Documentation
- Testing

___

Documentation for Lucia 1.0 can be found [here](env/Docs/tutorial.md).

[GNU 3.0 LICENSE](LICENSE)