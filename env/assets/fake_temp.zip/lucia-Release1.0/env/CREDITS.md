# Credits

Lucia Programming Language

## Contributors
- **SirPigari** - Lead Developer
- **ChatGPT** - AI Assistance & Code Suggestions
- **GitHub Copilot** - AI-Powered Code Assistance

Special thanks to the open-source community for inspiration and support!