def start(cmd):
    os.system(cmd)